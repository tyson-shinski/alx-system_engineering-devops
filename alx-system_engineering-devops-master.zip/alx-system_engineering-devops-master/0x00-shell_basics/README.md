Script for printing working directory
