stack debugging
