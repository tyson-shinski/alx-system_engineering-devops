Web stack debugging
