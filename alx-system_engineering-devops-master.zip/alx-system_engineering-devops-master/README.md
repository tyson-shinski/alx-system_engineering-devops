Printing working directory
